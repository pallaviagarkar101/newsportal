<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    } 


    /* Fetch & Insert values in table */
    if(isset($_POST['AddCategory']))  
    {
        $category = $_POST['category'];
        $CategoryDescription = $_POST['CategoryDescription'];
        $Status = 1;

        $q = "INSERT INTO category(category_name,category_description, Status) VALUES('$category','$CategoryDescription','$Status')";

        $result=mysqli_query($con,$q);

        if($result)
        {
            echo '<script> alert("Category Inserted Successfully...!"); </script>';
        }
        else
        {
            echo mysqli_error($con);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Add Category</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- Internal CSS -->
        <style type="text/css">
            #form{
                margin: 20px 10px 10px 60px;
            }
            label{
                color: black;
                font-size: 16px;
            }

        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Add Category</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Category </a>
                                        </li>
                                        <li class="active">
                                           Add Category
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-6">
                                <form method="post" id="form">
                                    <div class="form-group">
                                        <label>Category -</label>
                                        <input type="text" name="category" class="form-control" required="" autofocus="">
                                    </div><br>

                                    <div class="form-group">
                                        <label>Category Description - </label>
                                        <textarea class="form-control" rows="8" required="" name="CategoryDescription"></textarea>
                                    </div>

                                    <input type="submit" name="AddCategory" value="Submit" class="btn btn-success">
                                    <input type="reset" name="" value="Reset" class="btn btn-danger">

                                </form>
                                
                            </div>
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>
