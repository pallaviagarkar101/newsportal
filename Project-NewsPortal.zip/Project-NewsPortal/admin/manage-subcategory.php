<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    }   
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Manage Sub Category</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- Internal JavaScript -->
        <script type="text/javascript">
            function val()
            {
                if(!confirm("Do You Want to Delete Category..?"))
                {
                    return false;
                }
            }
        </script>

        <!-- Internal CSS -->
        <style type="text/css">
            #table1_head{
                background: #188ae2;
                color: white;
                font-size: 15px;
                border: 2px solid #188ae2;
            }

            #table1_body{
                border: 2px solid #188ae2;
            }

            #table2_head{
                background: #dc3545;
                color: white;
                font-size: 15px;
                border: 2px solid #dc3545;
            }

            #table2_body{
                border: 2px solid #dc3545;
            }
        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Manage Sub Category</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Sub Category </a>
                                        </li>
                                        <li class="active">
                                           Manage Sub Category
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-11">

                                <!-- Add Button -->
                                <div>
                                    <a href="add-subcategory.php">
                                        <button class="btn btn-success">Add <i class="fas fa-plus"></i></button>
                                    </a>
                                </div><br>

                                
                                <!-- Display All Sub Category -->
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead id="table1_head">
                                            <tr>
                                                <th>#</th>
                                                <th>Category</th>
                                                <th>Sub Category</th>
                                                <th>Sub Category <br>Description</th>
                                                <th>Posting Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table1_body">
                                            <?php 
$q = "select category.category_name, subcategory.subcategory_id, subcategory.subcategory_name, subcategory.subcategory_description, subcategory.postingDate from category RIGHT OUTER JOIN subcategory ON category.category_id=subcategory.category_id where subcategory.Status=1";

                                                $data = mysqli_query($con,$q);

                                                if($data)
                                                {
                                                    while($arr=mysqli_fetch_array($data))
                                                    {
echo "<tr><td>".$arr['subcategory_id']."</td><td>".$arr['category_name']."</td><td>".$arr['subcategory_name']."</td><td>".$arr['subcategory_description']."</td><td>".$arr['postingDate']."</td><td><a href='edit-subcategory.php?subcategory_id=".$arr['subcategory_id']."' class='text-primary'><i class='fas fa-pencil-alt'></i></a> &nbsp;&nbsp; <a href='manage-subcategory.php?subcategory_id=".$arr['subcategory_id']."&&action=trash' class='text-danger'><i class='fas fa-trash-restore'></i></a></td></tr>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo mysqli_error($con);
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div><br><hr>


                                <!--Deleted Sub Categories -->
                                <h3><i class='far fa-trash-alt'></i> Deleted Sub Categories</h3><br>

                                <!-- Display All Trash Sub Category -->
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead id="table2_head">
                                            <tr>
                                                <th>#</th>
                                                <th>Category</th>
                                                <th>Sub Category</th>
                                                <th>Sub Category <br>Description</th>
                                                <th>Posting Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table2_body">
                                            <?php 
$q = "select category.category_name, subcategory.subcategory_id, subcategory.subcategory_name, subcategory.subcategory_description, subcategory.postingDate from category RIGHT OUTER JOIN subcategory ON category.category_id=subcategory.category_id where subcategory.Status=0";

                                                $data = mysqli_query($con,$q);

                                                if($data)
                                                {
                                                    while($arr=mysqli_fetch_array($data))
                                                    {
echo "<tr><td>".$arr['subcategory_id']."</td><td>".$arr['category_name']."</td><td>".$arr['subcategory_name']."</td><td>".$arr['subcategory_description']."</td><td>".$arr['postingDate']."</td><td><a href='manage-subcategory.php?subcategory_id=".$arr['subcategory_id']."&&action=restore' class='text-primary'><i class='fas fa-undo-alt'></i></a> &nbsp;&nbsp; <a href='manage-subcategory.php?subcategory_id=".$arr['subcategory_id']."&&action=delete' class='text-danger' onclick='return val()'><i class='far fa-trash-alt'></i></a></td></tr>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo mysqli_error($con);
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div><br>
     
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <?php

            error_reporting(0);

            /* Sub Category Move to Trash */
            if($_GET['action']=='trash' && $_GET['subcategory_id'])
            {
                $subcategory_id = $_GET['subcategory_id'];
                $q = "UPDATE subcategory SET Status=0 WHERE subcategory_id=$subcategory_id";

                $result = mysqli_query($con,$q);

                if($result)
                {
                    echo '<script> alert("Sub Category Moved in trash...!"); </script>';
                }
                else
                {
                    echo mysqli_error($con);
                }
            } 


            /* Sub Category Restore */
            if($_GET['action']=='restore' && $_GET['subcategory_id'])
            {
                $subcategory_id = $_GET['subcategory_id'];
                $q = "UPDATE subcategory SET Status=1 WHERE subcategory_id=$subcategory_id";

                $result = mysqli_query($con,$q);

                if($result)
                {
                    echo '<script> alert("Sub Category Restored Successfuly...!"); </script>';
                }
                else
                {
                    echo mysqli_error($con);
                }
            }  


            /* Sub Category Delete */
            if($_GET['action']=='delete' && $_GET['subcategory_id'])
            {
                $subcategory_id = $_GET['subcategory_id'];
                $q = "DELETE FROM subcategory WHERE subcategory_id=$subcategory_id";

                $result = mysqli_query($con,$q);

                if($result)
                {
                    echo '<script> alert("Sub Category Deleted Successfuly...!"); </script>';
                }
                else
                {
                    echo mysqli_error($con);
                }
            }  
        ?>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>
