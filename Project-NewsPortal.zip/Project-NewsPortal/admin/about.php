<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    } 


    /* Fetch & Insert values in table */
    if(isset($_POST['about']))  
    {
        $page_name = "About US";
        $page_title = $_POST['page_title'];
        $page_description = $_POST['PageDescription'];

        $q = "UPDATE pages set page_title='$page_title',page_description='$page_description' where  page_name='$page_name'";

        $result=mysqli_query($con,$q);

        if($result)
        {
            echo '<script> alert("Page Infromation Updated Successfully...!"); </script>';
        }
        else
        {
            echo mysqli_error($con);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | About Us</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- Internal CSS -->
        <style type="text/css">
            #form{
                margin: 20px 10px 10px 60px;
            }
            label{
                color: black;
                font-size: 16px;
            }

        </style>
        
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">About Us</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Pages </a>
                                        </li>
                                        <li class="active">
                                           About Us
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <?php  
                            $page_name = "About US";
                            $query=mysqli_query($con,"select page_title,page_description from pages where page_name='$page_name'");

                            if($query)
                            {
                                while($arr=mysqli_fetch_array($query))
                                {
                        ?>
                               
                        <div class="row">
                            <div class="col-md-11">
                                <form method="post" id="form">
                                    <div class="form-group">
                                        <label>Page Title -</label>
                                        <input type="text" name="page_title" class="form-control" required="" value="<?php echo $arr['page_title']; ?>">
                                    </div><br>

                                    <div class="form-group">
                                        <label>Page Description - </label>
                                        <textarea class="form-control" rows="8" required="" name="PageDescription"><?php echo $arr['page_description']; ?></textarea>
                                    </div>

                                    <input type="submit" name="about" value="Update & Post" class="btn btn-success">

                                </form>
                                
                            </div>
                        </div>
                        <!-- end row -->
                        <?php
                                }
                            }    
                        ?>

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>
