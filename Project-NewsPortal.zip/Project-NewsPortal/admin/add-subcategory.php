<?php 
    session_start();

    error_reporting(0);

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    }   


    /* Fetch & Insert values in table */
    if(isset($_POST['AddSubCategory']))
    {
        $category_id=$_POST['category'];
        $subcategory=$_POST['subcategory'];
        $subcategory_description=$_POST['subcategory_description'];
        $status=1;

        $q = "INSERT INTO subcategory(category_id, subcategory_name, subcategory_description, Status) VALUES('$category_id','$subcategory','$subcategory_description','$status')";

        $result = mysqli_query($con,$q);

        if($result)
        {
            echo '<script> alert("Sub Category Inserted Successfully...!"); </script>';
        }
        else
        {
            echo mysqli_error($con);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Add Sub Category</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- Internal CSS -->
        <style type="text/css">
            #form{
                margin: 5px 10px 10px 60px;
            }
            label{
                color: black;
                font-size: 16px;
            }
        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Add Sub Category</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Sub Category </a>
                                        </li>
                                        <li class="active">
                                           Add Sub Category
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-6">
                                <form method="post" id="form">
                                    <div class="form-group">
                                        <label>Category -</label>
                                        <select name="category" class="form-control" required="">
                                            <option value=""> -Select Category-</option>
                                            <?php
                                                $q="SELECT category_id, category_name FROM category WHERE Status=1";
                                                $data=mysqli_query($con,$q);
                                                
                                                while($arr=mysqli_fetch_array($data))
                                                {
                                            ?>        
                                            <option value="<?php echo $arr['category_id']; ?>"> 
                                                <?php echo $arr['category_name'];?>
                                            </option>
                                            <?php } ?>                                    
                                        </select>
                                    </div><br>

                                    <div class="form-group">
                                        <label>Sub Category -</label>
                                        <input type="text" name="subcategory" class="form-control" required="">
                                    </div><br>

                                    <div class="form-group">
                                        <label>Sub Category Description - </label>
                                        <textarea class="form-control" rows="5" required="" name="subcategory_description"></textarea>
                                    </div>

                                    <input type="submit" name="AddSubCategory" value="Submit" class="btn btn-success">
                                    <input type="reset" name="" value="Reset" class="btn btn-danger">
                                </form>
                                
                            </div>
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>
