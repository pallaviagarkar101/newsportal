<?php 
	session_start();

	if(session_destroy())
	{
		echo'<script> alert("You have successfully logged out."); window.location="admin_login.php" </script>';
	}
?>