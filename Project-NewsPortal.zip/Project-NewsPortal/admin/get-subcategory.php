<?php

    /* Database Configuration File */
    include('includes/config.php');

    if(!empty($_POST["category_id"])) 
    {

        $category_id=intval($_POST['category_id']);

        $q = "SELECT * FROM subcategory WHERE category_id='$category_id' and Status=1";

        $data=mysqli_query($con, $q);
?>
        <option value="">-Select Subcategory-</option>

<?php
        while($row=mysqli_fetch_array($data))
        {
?>
            <option value="<?php echo $row['subcategory_id']; ?>"><?php echo $row['subcategory_name']; ?></option>
<?php
        }
    }
?>