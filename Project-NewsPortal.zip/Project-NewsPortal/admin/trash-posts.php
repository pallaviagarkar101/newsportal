<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    }   
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Trashed Posts</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- Internal CSS -->
        <style type="text/css">

            #table2_head{
                background: #dc3545;
                color: white;
                font-size: 15px;
                border: 2px solid #dc3545;
            }

            #table2_body{
                border: 2px solid #dc3545;
            }
        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Trashed Posts</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Posts </a>
                                        </li>
                                        <li class="active">
                                           Trashed Posts
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-12">

                                <!-- Display All Trash Post -->
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead id="table2_head">
                                            <tr>
                                                <th>#</th>
                                                <th>Post Title</th>
                                                <th>Category</th>
                                                <th>Sub Category</th>
                                                <th>Posting Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table2_body">
                                            <?php 
                                                $q = "select post.post_id,
                                                post.post_title,category.category_name,subcategory.subcategory_name,post.postingDate FROM post left join category on category.category_id=post.category_id left join subcategory on subcategory.subcategory_id=post.subcategory_id WHERE post.Status=0";

                                                $data = mysqli_query($con,$q);

                                                if($data)
                                                {
                                                    while($arr=mysqli_fetch_array($data))
                                                    {
echo "<tr><td>".$arr['post_id']."</td><td>".$arr['post_title']."</td><td>".$arr['category_name']."</td><td>".$arr['subcategory_name']."</td><td>".$arr['postingDate']."</td><td><a href='trash-posts.php?post_id=".$arr['post_id']."&&action=restore'><i class='fas fa-undo-alt'></i></a> &nbsp;&nbsp; <a href='trash-posts.php?post_id=".$arr['post_id']."&&action=delete' class='text-danger'><i class='far fa-trash-alt'></i></a></td></tr>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo mysqli_error($con);
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                  
                            </div>
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->

        <?php
    
            error_reporting(0);

            /* Category Restore */
            if($_GET['action']=='restore' && $_GET['post_id'])
            {
                $post_id = $_GET['post_id'];
                $q = "UPDATE post SET Status=1 WHERE post_id=$post_id";

                $result = mysqli_query($con,$q);

                if($result)
                {
                    echo '<script> alert("Post Restored Successfuly...!"); </script>';
                }
                else
                {
                    echo mysqli_error($con);
                }
            }  


            /* Category Delete */
            if($_GET['action']=='delete' && $_GET['post_id'])
            {
                $post_id = $_GET['post_id'];
                $q = "DELETE FROM post WHERE post_id=$post_id";

                $result = mysqli_query($con,$q);

                if($result)
                {
                    echo '<script> alert("Post Deleted Successfuly...!"); </script>';
                }
                else
                {
                    echo mysqli_error($con);
                }
            }   
        ?>


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>
