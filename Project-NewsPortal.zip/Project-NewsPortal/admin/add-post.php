<?php 
    session_start();
    error_reporting(0);

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    } 

    /* Fetch & Insert Post values in table  */

    if(isset($_POST['AddPost']))
    {
        $PostTitle=$_POST['PostTitle'];
        $category_id=$_POST['category'];
        $subcategory_id=$_POST['subcategory'];
        $postDetails=$_POST['postDetails'];
        $imgfile=$_FILES["img"]["name"];

        // get the image extension
        $extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));

        // allowed extensions
        $allowed_extensions = array(".jpg",".jpeg",".png",".gif");
        // Validation for allowed extensions .in_array() function searches an array for a specific value.


        if(!in_array($extension,$allowed_extensions))
        {
            echo "<script> alert('Invalid format. Only jpg / jpeg/ png /gif format allowed..'); </script>";
        }
       else
        {
            //rename the image file
            $imgnewfile=md5($imgfile).$extension;

            // Code for move image into directory
            move_uploaded_file($_FILES["img"]["tmp_name"],
                "postimages/".$imgnewfile);

            $Status = 1;

            $q = "INSERT INTO post(post_title,category_id,subcategory_id,post_details,Status,post_image) VALUES('$PostTitle','$category_id','$subcategory_id','$postDetails','$Status',
            '$imgnewfile')";

            $data=mysqli_query($con, $q);

            if($data)
            {
                echo "<script> alert('Post Added Successfuly..!!'); </script>";
            }
            else
            {
                echo mysqli_error($con);
            } 
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Add Posts</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

      

        <!-- Internal CSS -->
        <style type="text/css">
            #form{
                margin: 5px 10px 10px 60px;
            }
            label{
                color: black;
                font-size: 16px;
            }
        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Add Posts</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Posts </a>
                                        </li>
                                        <li class="active">
                                           Add Posts
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-11">
                                <form method="post" id="form" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label>Post Title -</label>
                                        <input type="text" name="PostTitle" class="form-control" required="" autofocus="">
                                    </div><br>

                                    <div class="form-group">
                                        <label>Category -</label>
                                        <select name="category" class="form-control" required="" onchange="subcat()" id="category">
                                            <option value=""> -Select Category-</option>
                                            <?php
                                                $q="SELECT category_id, category_name FROM category WHERE Status=1";
                                                $data=mysqli_query($con,$q);
                                                
                                                while($arr=mysqli_fetch_array($data))
                                                {
                                            ?>        
                                            <option value="<?php echo $arr['category_id']; ?>"> 
                                                <?php echo $arr['category_name'];?>
                                            </option>
                                            <?php } ?>                                    
                                        </select>
                                    </div><br>

                                    <div class="form-group">
                                        <label>Sub Category -</label>
                                        <select class="form-control" name="subcategory" id="subcategory" required="">    
                                        </select> 
                                    </div><br>

                                    <div class="form-group">
                                        <label>Post Details - </label>
                                        <textarea class="form-control" rows="8" required="" name="postDetails"></textarea>
                                    </div><br>

                                    <div class="form-group">
                                        <label>Image -</label>
                                        <input type="file" class="form-control" name="img"  required="">
                                    </div><br>

                                    <input type="submit" name="AddPost" value="Save and Post" class="btn btn-success">
                                    <input type="reset" name="" value="Reset" class="btn btn-danger">
                                </form><br>
                                
                            </div>
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

          <script>
            function subcat()
            {
                
                
                var val=$("#category").val();
               
                $.ajax({
                type: "POST",
                url: "get-subcategory.php",
                data:'category_id='+val,
                success: function(data)
                {
                    
                    $("#subcategory").html(data);
                }
                  
                });
                
                }
        </script>
    </body>
</html>
