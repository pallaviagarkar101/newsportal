<?php
	session_start();

	/* defined variable: message*/
	$message="";

	/* Database Configuration File */
	include('includes/config.php');

	if(isset($_POST['signin']))
	{
		/* Getting Username/ Email and Password */
		$username=$_POST['username'];
		$password=$_POST['password'];

		/* Database Connection */
		$query="SELECT * FROM admin_login WHERE username='$username' and password='$password'";
		$data=mysqli_query($con, $query);

		if($data)
		{
			if(mysqli_num_rows($data)>0)
			{
				$_SESSION['username']=$username;
				header("Location:dashboard.php");
			}

			/* if username or email not found in database */
			else 
			{
				$message = '<p style="color:#ff0000; text-align:center; font-size:18px;"> Username or Password is incorrect.</p>'; 
		        //echo "<script> alert('Wrong username or password') </script>";
		    }
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<!-- App Title -->
	<title>Admin Login</title>

	<!-- CDN for Icons -->
	<script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

	<!-- Bootstrap CSS File -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/bootstrap.css">

	<!-- Jquery File -->
	<script type="text/javascript" src="assets/jquery/jquery.js"></script>

	<!-- Jquery For Show Password -->
	<script type="text/javascript">

		$(document).ready(function(){
			$("#showpassword").change(function(){

				if($(this).is(':checked'))
				{
	   				$("#password").attr("type","text");  
				}
				else
				{
	   				$("#password").attr("type","password");
	   			}		
			});
		});
	</script>

	<!-- Internal CSS -->
	<style type="text/css">
		*{
			padding: 0px;
			margin: 0px;
		}

		#heading{
			background: #505458;
			color: white;
			text-align: center;
			padding: 20px;
			border-radius: 15px;
			font-size: 25px;
			letter-spacing: 3px;
			font-weight: 700;
		}

		#main{
			padding: 30px;
			border: 2px solid #f2f2f2;
			box-shadow: 10px 10px 5px #f2f2f2;
			margin-top: 70px;
		}
	</style>
</head>
<body>

	<!-- Admin Login -->
	<section>
		<div class="container">
			<div class="row">
				<div class="col-8 col-sm-8 col-md-6 col-lg-5 col-xl-5 mx-auto" id="main">

					<h3 id="heading">NEWS<span style="color:#4360b5">PORTAL</span><br> Admin Login</h3><br>

					<?php 
					/* if username or email not found in database */
					echo $message; 
					?>

					<form autocomplete="off" method="post"> 
						<div class="form-group input-group">
							<div class="input-group-prepend">
							    <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" name="username" placeholder="Username or Email" required=""  class="form-control" aria-label="Username" aria-describedby="basic-addon1">
						</div>

						<div class="form-group input-group"> 
							<div class="input-group-prepend">
							    <span class="input-group-text" id="basic-addon"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" id="password" name="password" placeholder="Password" required="" class="form-control" aria-label="Password" aria-describedby="basic-addon">
						</div>	

						<div class="form-check">
							<input type="checkbox" id="showpassword" name="showpassword" class="form-check-input">Show Password 
						</div><br>

						<input type="submit" value="Sign in" name="signin" class="btn btn-primary btn-block">	
					</form>	
				</div>	
			</div>
		</div>
	</section>
	
</body>	
</html>