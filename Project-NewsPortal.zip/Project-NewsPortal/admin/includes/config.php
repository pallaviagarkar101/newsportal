<?php 
	$con=mysqli_connect("localhost","root","","project_newsportal");

	// Check connection
	if (mysqli_connect_errno())
	{
	 echo "Failed to Connect to MySQL: " . mysqli_connect_error();
	}
?>