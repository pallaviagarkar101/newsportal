<?php 
    session_start();
    error_reporting(0);

    /* Database Configuration File */
    include('includes/config.php');

    $username=$_SESSION['username'];

    if(isset($_SESSION['username']))
    {
        
    }
    else
    {
        header("Location:admin_login.php");
    }   
?>

<?php 
     
    /* Fetch Data From Post Table */
    if($con)
    {
        $post_id = $_REQUEST['post_id'];

        $q="select post.post_id,post.post_title,post.post_details,post. post_image, category.category_name,category.category_id, subcategory.subcategory_name,subcategory.subcategory_id FROM post left join category on category.category_id=post.category_id left join subcategory on subcategory.subcategory_id=post.subcategory_id WHERE post.post_id=$post_id and post.Status=1";

        $data=mysqli_query($con,$q);

        $arr1=mysqli_fetch_array($data);
    }


    /* Update data In Post Table */
    if(isset($_POST['Update']))
    {
        $post_id = $_REQUEST['post_id'];
        $post_title = $_POST['PostTitle'];
        $category_id  = $_POST['category'];
        $subcategory_id = $_POST['subcategory'];
        $post_details = $_POST['postDetails'];

        $q = "update post set post_title='$post_title', category_id='$category_id', subcategory_id='$subcategory_id', post_details='$post_details' where post_id=$post_id";

        $result = mysqli_query($con, $q);

        if($result)
        {
            echo "<script> alert('Post Updated Successfully..!!'); </script>";
        }
        else
        {
            echo mysqli_error($con);
        } 
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App title -->
        <title>NewsPortal | Edit Posts</title>

        <!-- CDN for Icons -->
        <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" /> 
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

      

        <!-- Internal CSS -->
        <style type="text/css">
            #form{
                margin: 5px 10px 10px 60px;
            }
            label{
                color: black;
                font-size: 16px;
            }

            #img{
                border: 1px solid #d9d9d9;
                padding: 15px;
            }
        </style>
		
    </head>

    <body class="fixed-left">

        <!-- Start wrapper -->
        <div id="wrapper">

            <!-- Top Bar -->
            <?php include('includes/topheader.php'); ?>

            
            <!-- Left Sidebar -->
            <?php include('includes/leftsidebar.php'); ?>


            <!-- Start Content -->
            <div class="content-page">

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Edit Posts</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">NewsPortal</a>
                                        </li>
                                        <li>
                                            <a href="#">Admin </a>
                                        </li>
                                        <li>
                                            <a href="#">Posts </a>
                                        </li>
                                        <li class="active">
                                           Edit Posts
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
						</div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-11">
                                <form method="post" id="form" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label>Post Title -</label>
                                        <input type="text" name="PostTitle" class="form-control" required="" value=" <?php echo $arr1['post_title']; ?> ">
                                    </div><br>

                                    <div class="form-group">
                                        <label>Category -</label>
                                        <select name="category" class="form-control" required="" onchange="subcat()" id="category">
                                            <option value="<?php echo $arr1['category_id']; ?> "> <?php echo $arr1['category_name']; ?> </option>

                                            <?php
                                                $q="SELECT category_id, category_name FROM category WHERE Status=1";
                                                $data=mysqli_query($con,$q);
                                                
                                                while($arr=mysqli_fetch_array($data))
                                                {
                                            ?>        
                                            <option value="<?php echo $arr['category_id']; ?>"> 
                                                <?php echo $arr['category_name'];?>
                                            </option>
                                            <?php } ?>                                    
                                        </select>
                                    </div><br>

                                    <div class="form-group">
                                        <label>Sub Category -</label>
                                        <select class="form-control" name="subcategory" id="subcategory" required=""> 
                                        <option value="<?php echo $arr1['subcategory_id']; ?> "> <?php echo $arr1['subcategory_name']; ?></option>   
                                        </select> 
                                    </div><br>

                                    <div class="form-group">
                                        <label>Post Details - </label>
                                        <textarea class="form-control" rows="8" required="" name="postDetails"><?php echo $arr1['post_details']; ?></textarea>
                                    </div><br>

                                    <div class="form-group" id="img">
                                        <label>Post Image -</label><br>
                                    
                                        <img src="postimages/<?php 
                                        echo $arr1['post_image']; ?>" height="200" width="320">

                                        <br><br>

                                        <a href="change_image.php?post_id=<?php echo $arr1['post_id']; ?>" style="font-size: 18px;">Update Image</a>
                                    </div>
                                    <br>

                                    <input type="submit" name="Update" value="Update" class="btn btn-primary">
                                </form><br>
                                
                            </div>
                        </div>
                        <!-- end row -->

                    </div> <!-- End container -->

                </div> <!-- End content -->


                <!-- Footer -->
                <?php include('includes/footer.php');?>

            </div><!-- End Content -->

        </div>
        <!-- End wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

          <script>
            function subcat()
            {
                
                
                var val=$("#category").val();
               
                $.ajax({
                type: "POST",
                url: "get-subcategory.php",
                data:'category_id='+val,
                success: function(data)
                {
                    
                    $("#subcategory").html(data);
                }
                  
                });
                
                }
        </script>
    </body>
</html>
