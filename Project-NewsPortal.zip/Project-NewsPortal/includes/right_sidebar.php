<div class="card">
	<h4 class="card-header">Search</h4>

	<div class="card-body">
		<form method="post">
			<div class="input-group">
           
        		<input type="text" name="searchtitle" class="form-control" placeholder="Search....." required>
                <span class="input-group-btn">
                  <button class="btn btn-success" type="submit">Search</button>
                </span>
		</form>
		</div>
</div></div><br>


<!-- Category -->
<div class="card">
	<h4 class="card-header">Categories</h4>

	<div class="card-body">
		<ul class="list-unstyled mb-0">
			<?php 

				$query=mysqli_query($con,"select category_id,category_name from category group by category_name");

				while($arr=mysqli_fetch_array($query))
				{
			?>
			<li>
				<a href="category.php?category_id=<?php echo $arr['category_id']; ?>"><?php echo $arr['category_name']; ?></a>
			</li>
			<?php
				}
			?>	
		</ul>
				
	</div>
</div><br>



<!-- post -->
<div class="card">
	<h4 class="card-header">Recent News</h4>

	<div class="card-body">
		<ul>
			<?php 

				$query=mysqli_query($con,"select post_id,post_title from post");

				while($arr=mysqli_fetch_array($query))
				{
			?>
			<li>
				<a href="news_details.php?post_id=<?php echo $arr['post_id']; ?>"><?php echo $arr['post_title']; ?></a>
			</li>
			<?php
				}
			?>	
		</ul>
				
	</div>
</div>
