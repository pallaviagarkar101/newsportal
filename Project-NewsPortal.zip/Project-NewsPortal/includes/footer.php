<footer style="height: 70px; width: 100%; font-size: 18px; text-align: center; padding-top: 25px;" class="bg-dark text-white">
      <p>2021 © CNC WebWorld </p>
</footer>