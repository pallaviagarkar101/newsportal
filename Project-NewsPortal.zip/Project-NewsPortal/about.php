<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- App Title -->
	<title>News Portal | About Us</title>

	<!-- Bootstrap File -->
	<link rel="stylesheet" type="text/css" href="assets/Bootstrap/bootstrap.css">
	<script type="text/javascript" src="assets/Bootstrap/jquery_3.4.1.js"></script>
	<script type="text/javascript" src="assets/Bootstrap/popper.js"></script>
	<script type="text/javascript" src="assets/Bootstrap/bootstrap_4.4.1.js"></script>

	<!-- Internal CSS -->
	<style type="text/css">
		#detail{
			line-height: 32px;
			font-size: 20px;
			text-align: justify;
		}
	</style>

</head>
<body>
	<!-- NavBar Start -->
	<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
		<div class="container">
			<a href="#" class="navbar-brand"><h2><span class="text-primary">NEWS</span>PORTAL</h2></a>

			<button class="navbar-toggler" data-toggle="collapse" data-target="#navid">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navid">
			 	<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a href="index.php" class="nav-link"><h5>News</h5></a>
					</li>

					<li class="nav-item">
						<a href="about.php" class="nav-link active"><h5>About Us</h5></a>
					</li> 
			
					<li class="nav-item">
						<a href="contact.php" class="nav-link"><h5>Contact Us</h5></a>
					</li> 			
				</ul>	
			</div>
		</div>		
	</nav>
	<!-- NavBar End -->


	<br><br><br><br>
	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 mx-auto">

				<?php 

					$page_name = "About US";

                    $query=mysqli_query($con,"select page_title,page_description from pages where page_name='$page_name'");

                    if($query)
                    {
                    	while($arr=mysqli_fetch_array($query))
                        {
				?>

				<h1><?php echo $arr['page_title']; ?></h1><br>

				<p id="detail"><?php echo $arr['page_description']; ?>  </p>

				<?php
						}
					}
				?>		

			</div>
		</div>	
	</div><br><br><br>

	<!-- Footer -->
	<?php include('includes/footer.php'); ?>

</body>
</html>