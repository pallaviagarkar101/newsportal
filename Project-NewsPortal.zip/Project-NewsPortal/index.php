<?php 
    session_start();

    /* Database Configuration File */
    include('includes/config.php');
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- App Title -->
	<title>News Portal | Home Page</title>

	<!-- Bootstrap File -->
	<link rel="stylesheet" type="text/css" href="assets/Bootstrap/bootstrap.css">
	<script type="text/javascript" src="assets/Bootstrap/jquery_3.4.1.js"></script>
	<script type="text/javascript" src="assets/Bootstrap/popper.js"></script>
	<script type="text/javascript" src="assets/Bootstrap/bootstrap_4.4.1.js"></script>

	<!-- CDN for Icons -->
    <script src="https://kit.fontawesome.com/747bd49855.js" crossorigin="anonymous"></script>

</head>
<body>
	<!-- NavBar Start -->
	<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
		<div class="container">
			<a href="#" class="navbar-brand"><h2><span class="text-primary">NEWS</span>PORTAL</h2></a>

			<button class="navbar-toggler" data-toggle="collapse" data-target="#navid">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navid">
			 	<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a href="index.php" class="nav-link active"><h5>News</h5></a>
					</li>

					<li class="nav-item">
						<a href="about.php" class="nav-link"><h5>About Us</h5></a>
					</li> 
			
					<li class="nav-item">
						<a href="contact.php" class="nav-link"><h5>Contact Us</h5></a>
					</li> 			
				</ul>	
			</div>
		</div>		
	</nav><br><br><br><br>
	<!-- NavBar End -->


	<!-- Start content -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-8 col-xl-8">

				<?php 
					$q = "select post.post_id,post.post_title,post.post_image,post.postingDate,post.post_details,category.category_name,category.category_id, subcategory.subcategory_name FROM post left join category on category.category_id=post.category_id left join subcategory on subcategory.subcategory_id=post.subcategory_id WHERE post.Status=1 order by post.post_id desc";

    				$result=mysqli_query($con, $q);

    				if($result)
    				{
    					while($arr=mysqli_fetch_array($result))
    					{ 
				?>

					<div class="card mb-5">
						<img class="card-img-top" src="admin/postimages/<?php echo $arr['post_image']; ?>" alt="<?php echo $arr['post_title']; ?>" height="350">

						<div class="card-body">
							<h2 class="card-title"><?php echo $arr['post_title']; ?> </h2>

							<p><b>Category : </b> <a href="category.php?category_id=<?php echo $arr['category_id']; ?>"><?php echo $arr['category_name']; ?> </a> </p>
				       
				            <a href="news_details.php?post_id=<?php echo $arr['post_id']; ?>" class="btn btn-primary">Read More &rarr;</a>	
						</div>	

						<div class="card-footer text-muted">
			              Posted on <?php echo $arr['postingDate']; ?>
			            </div>
					</div>

				<?php
						}
    				}
				?>
			</div>
			<!-- col End -->

			<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4">
				<!-- Right Sidebar-->
      			<?php include('includes/right_sidebar.php'); ?>
			</div>	
			<!-- col End -->	
		</div>
		<!-- row End -->
	</div>
	<!-- Container End -->


	<!-- Footer -->
	<?php include('includes/footer.php'); ?>

</body>
</html>